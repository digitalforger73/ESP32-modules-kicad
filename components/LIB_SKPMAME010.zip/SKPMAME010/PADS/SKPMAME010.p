*PADS-LIBRARY-PART-TYPES-V9*

SKPMAME010 SKPMAME010 I SWI 9 1 0 0 0
TIMESTAMP 2026.07.24.04.18.44
"Manufacturer_Name" ALPS Electric
"Manufacturer_Part_Number" SKPMAME010
"Mouser Part Number" 688-SKPMAM
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Alps-Alpine/SKPMAME010?qs=m0BA540hBPd%252BuZ6zBVIW%252Bw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" ALPS - SKPMAME010 - SWITCH, TACTILE, 1.57N, 6X6MM
"Datasheet Link" https://www.alps.com/prod/info/E/HTML/Tact/SurfaceMount/SKPM/SKPMAME010.html
"Geometry.Height" 5.2mm
GATE 1 2 0
SKPMAME010
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
343150/585793/2.50/2/3/Switch
