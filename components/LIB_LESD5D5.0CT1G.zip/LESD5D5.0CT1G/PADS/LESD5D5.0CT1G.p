*PADS-LIBRARY-PART-TYPES-V9*

LESD5D5.0CT1G LESD5D50CT1G I DIO 9 1 0 0 0
TIMESTAMP 2026.07.24.04.17.40
"Manufacturer_Name" LRC
"Manufacturer_Part_Number" LESD5D5.0CT1G
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Transient Voltage Suppressors for ESD Protection
"Datasheet Link" 
"Geometry.Height" 0.7mm
GATE 1 2 0
LESD5D5.0CT1G
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
1953855/585793/2.50/2/4/TVS Diode (Bi-directional)
