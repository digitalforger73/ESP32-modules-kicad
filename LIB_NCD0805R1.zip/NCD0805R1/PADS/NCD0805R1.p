*PADS-LIBRARY-PART-TYPES-V9*

NCD0805R1 NCD0805R1 I DIO 9 1 0 0 0
TIMESTAMP 2026.07.24.04.19.19
"Manufacturer_Name" NATIONSTAR
"Manufacturer_Part_Number" NCD0805R1
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Chip Light Emitting Diode 25mA, 50mA, 5V, 65mW, -30 ~ +85 Forward Current	25mA	 Operating Temperature	-30~+85	 Voltage - Forward(Vf)	1.6V~2.6V	 Wavelength - Dominant	615nm~630nm	 Diode Configuration	Discrete Diode	 Luminous Intensity	195mcd
"Datasheet Link" https://www.unikeyic.com/media/datasheet/e8/15/b6fe/e815b6fea8a81f083d58adf4c98a1642.pdf
"Geometry.Height" 1.2mm
GATE 1 2 0
NCD0805R1
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
21999911/585793/2.50/2/4/LED
