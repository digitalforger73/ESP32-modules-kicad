*PADS-LIBRARY-PART-TYPES-V9*

KT-0805G KT0805G I DIO 9 1 0 0 0
TIMESTAMP 2026.07.24.04.21.07
"Manufacturer_Name" Hubei KENTO Elec
"Manufacturer_Part_Number" KT-0805G
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Emerald Green 0805 LED Indication 100 mW 60 mA 5 V -40C ~ + 85C - Discrete ROHS,Package ( L/W/H ) : 2.0*1.25*0.85 mm
"Datasheet Link" https://jlcpcb.com/api/file/downloadByFileSystemAccessId/8639582106239348736
"Geometry.Height" 0.95mm
GATE 1 2 0
KT-0805G
2 0 U K
1 0 U A

*END*
*REMARK* SamacSys ECAD Model
20772626/585793/2.50/2/3/LED
